# Chapterhouse — Final Fixed Package (Next.js + Supabase)

## 1) Env
Create `.env.local` in project root:
NEXT_PUBLIC_SUPABASE_URL=https://YOUR-REF.supabase.co
NEXT_PUBLIC_SUPABASE_ANON_KEY=YOUR-ANON-KEY

## 2) Install & run
npm install
npm run dev
(Ports tab → make port 3000 Public → open)

## 3) Supabase setup
SQL Editor → paste `supabase/migrations/001_setup.sql` → Run
Auth → Users → Add user (your admin email), set password, Confirm user
(Optional) add email to allow-list:
insert into public.admins(email) values ('YOUR_EMAIL') on conflict do nothing;

## 4) Routes
/ , /books , /admin/login , /admin/dashboard
